Scream sound by tharnvannispen https://freesound.org

Use WASD keys to move
Press Space to mine
Press P to summon a magic locator, which will scream and disappear when it detects magic in a 5x5 area around the player